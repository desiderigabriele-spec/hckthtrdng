# SUPER PROMPT — LOVABLE
**Project: Signal Room Website — Hacker Terminal Aesthetic**

> Copy and paste this entire prompt into Lovable. Replace `[BRAND_NAME]` with your chosen brand name before sending. Suggested names: `ROOT.SIGNAL`, `PROTOCOL_X`, `NULL_SIGNAL_FX`, `DARK_EDGE`, `TR4DER_OS`.

---

```
Build a single-page website (with optional sub-pages) in Italian for a trading signal community called [BRAND_NAME]. The brand is an Introducing Broker affiliated with Fortune Prime Global (FPG), an ASIC-regulated forex broker. The site's job is to convert visitors into signal room members who open a trading account on FPG via the IB referral link.

================================================================
1. CORE POSITIONING
================================================================

We are NOT financial advisors. We are a community of traders who use proprietary AI algorithms as a support tool for technical and fundamental market analysis. We share signals as educational content, not as personalized investment advice. The decision to trade is always the user's.

The brand contrasts with the typical Italian trading guru market (Lamborghini, lifestyle, "easy money"). Our positioning is the opposite: cold, technical, anonymous, systematic. Like a hacker terminal. Like a system that speaks, not an influencer that shouts.

================================================================
2. BRAND IDENTITY — HACKER TERMINAL AESTHETIC
================================================================

VISUAL REFERENCE: classic hacker terminal screens (think r/unixporn, Mr. Robot, The Matrix, ASCII art, multiple tmux panes, htop output, ncurses interfaces).

COLOR PALETTE (use as CSS variables):
--bg-primary: #0D0D0D (deep black, almost pure)
--bg-secondary: #1A1A1A (slightly lighter for cards)
--terminal-green: #00FF41 (primary accent, signals LONG)
--terminal-red: #FF0033 (signals SHORT, warnings, alerts)
--terminal-amber: #FFB800 (highlights, CTAs)
--text-primary: #E5E5E5 (light gray, NOT pure white)
--text-dim: #888888 (secondary text)
--border-grid: #2A2A2A (subtle grid lines)

TYPOGRAPHY:
- Headings: "Bebas Neue" or "Anton" (condensed, uppercase, dramatic)
- Body: "Inter" or "DM Sans" (clean, readable)
- Code/Terminal elements: "JetBrains Mono" or "Fira Code" (monospace, mandatory for all terminal-style content)

VISUAL EFFECTS (use sparingly, never on the entire page):
- Typewriter effect on hero headline (text appears character by character)
- Subtle CRT scanline overlay on hero section only (very faint, 5% opacity)
- Blinking cursor "▊" or "█" after key text elements
- Glitch effect on hover for primary CTAs (RGB split, 200ms duration)
- ASCII art dividers between sections (e.g., "═══════════════════")
- Terminal prompt prefix on section headers: "$ ", "> ", "[ROOT@SIGNAL ~]#"
- Subtle green text glow (text-shadow: 0 0 8px rgba(0,255,65,0.4)) on key elements

DO NOT:
- Use the Matrix falling characters background (overused cliché)
- Add gratuitous animations on scroll
- Use stock photos of traders with multiple monitors
- Use any emoji
- Use rounded corners aggressively — keep most elements sharp/square or 2px max radius

================================================================
3. TECH STACK
================================================================

- React + TypeScript (Vite default in Lovable)
- Tailwind CSS for styling
- Framer Motion for the typewriter and glitch effects only
- Lucide React for icons (use sparingly: Terminal, Lock, Zap, Activity, AlertTriangle, ChevronRight)
- Supabase for newsletter signup + lead capture (create a `leads` table: id, email, telegram_handle, created_at, source)
- Responsive: mobile-first, breakpoints at 768px (tablet) and 1024px (desktop)
- Fast loading: optimize fonts (font-display: swap), lazy load below-the-fold sections

================================================================
4. SITE ARCHITECTURE
================================================================

Single-page site with smooth scroll, plus 3 supporting pages:

MAIN PAGE SECTIONS (in order):
1. Hero with terminal animation
2. The Problem (why retail traders lose)
3. The System (how AI + human traders work together)
4. Signal Room Preview (sample signal display, blurred for non-members)
5. The Edge (3-4 key features in terminal-card format)
6. Live Stats Bar (animated counters)
7. How It Works (3 steps: register FPG → join Telegram → receive signals)
8. Testimonials (terminal-styled, anonymized — "USER_3471", "USER_8829")
9. FAQ (accordion, monospace question prefix)
10. Final CTA + lead capture form
11. Footer with full legal disclaimers

SUPPORTING PAGES:
- /disclaimer — full risk disclaimer page
- /privacy — privacy policy + cookie policy
- /terms — terms of service

================================================================
5. PAGE-BY-PAGE COPY (ITALIAN)
================================================================

──────────────────────────────────────────────
HERO SECTION
──────────────────────────────────────────────
Background: solid #0D0D0D with subtle grid pattern (1px lines, #1A1A1A, 80px spacing)

Top-left badge (small, monospace): 
`[SYSTEM ONLINE]` (green text, blinking dot before)

Pre-headline (small, monospace, terminal-amber):
`> initializing market analysis protocol...`

Main headline (Bebas Neue, 5xl-7xl, white):
**ANALISI TECNICA AUTOMATIZZATA**
**PER TRADER CHE NON HANNO TEMPO**
**DA PERDERE.**

Sub-headline (Inter, lg, text-dim):
Segnali generati da trader professionisti supportati da algoritmi di intelligenza artificiale proprietari. Filtriamo il rumore del mercato. Tu prendi la decisione finale.

CTA primary (terminal-green bg, black text, monospace, sharp corners):
`> ACCEDI ALLA SALA SEGNALI`

CTA secondary (transparent, green border, green text):
`[SCOPRI IL SISTEMA]`

Bottom of hero — animated terminal output (typewriter effect on loop):
```
$ system.scan --markets=forex,gold,indices
[OK] EUR/USD ............ MONITORING
[OK] XAU/USD ............ SIGNAL DETECTED
[OK] GBP/JPY ............ ANALYZING
[OK] US30 ............... NEUTRAL
[INFO] 247 patterns evaluated in 0.34s
```

──────────────────────────────────────────────
SECTION 2 — THE PROBLEM
──────────────────────────────────────────────
Header (monospace, dim): `// PROBLEM_STATEMENT`
Title (Bebas Neue, huge): IL 78% DEI TRADER RETAIL PERDE DENARO.
Subtitle: Non per mancanza di intelligenza. Per mancanza di sistema.

3 cards in a row, each with:
- Terminal-style header in red: `[ERROR_01]`, `[ERROR_02]`, `[ERROR_03]`
- Title + 2 lines of body

Card 1: BIAS EMOTIVO
Paura, FOMO, revenge trading. Il 90% degli errori in trading è psicologico, non tecnico.

Card 2: INFORMAZIONI INCOMPLETE
Un trader umano monitora 3-4 strumenti. Il mercato muove decine di asset correlati ogni secondo.

Card 3: TIMING
Identificare un setup tecnico richiede tempo. Quando lo vedi a occhio, l'opportunità è già passata.

──────────────────────────────────────────────
SECTION 3 — THE SYSTEM
──────────────────────────────────────────────
Header: `// SOLUTION_STACK`
Title: IL NOSTRO PROTOCOLLO.

Layout: split 50/50. Left side text, right side animated terminal mockup.

Text (left):
Combiniamo tre livelli operativi:

`> LAYER_01` ALGORITMI AI PROPRIETARI
Scansionano 50+ strumenti in tempo reale, identificano pattern statistici e setup tecnici ricorrenti su timeframe multipli.

`> LAYER_02` TRADER PROFESSIONISTI
Validano ogni segnale generato dal sistema. Filtrano i falsi positivi. Decidono cosa pubblicare in sala.

`> LAYER_03` SISTEMA DI ALERT
Quando un setup ha probabilità statistica sufficiente, ricevi il segnale su Telegram con: pair, direzione, entry, stop loss, target. Decidi tu se entrare.

Terminal mockup (right):
Show a fake terminal with output like:
```
[14:23:07] SCAN_INITIATED
[14:23:07] Analyzing 52 instruments...
[14:23:08] Pattern detected: XAU/USD
[14:23:08] Confidence: 73%
[14:23:08] Validating with human trader...
[14:23:42] SIGNAL_APPROVED
[14:23:42] Broadcasting to channel...
```

──────────────────────────────────────────────
SECTION 4 — SIGNAL ROOM PREVIEW
──────────────────────────────────────────────
Header: `// LIVE_PREVIEW`
Title: COSA RICEVI NELLA SALA.

Show a Telegram-style chat mockup with 3-4 sample signals (clearly labeled "ESEMPIO ILLUSTRATIVO"):

Message 1 (timestamp 09:34):
```
🟢 SIGNAL #0247
PAIR: EUR/USD
DIRECTION: LONG
ENTRY: 1.0842
SL: 1.0815
TP1: 1.0875
TP2: 1.0910
CONFIDENCE: 71%
ANALYSIS: Breakout struttura H4 + 
divergenza RSI confermata
```

Message 2 (timestamp 11:12):
```
🔴 SIGNAL #0248
PAIR: XAU/USD
DIRECTION: SHORT
ENTRY: 2387.50
SL: 2395.00
TP1: 2378.00
CONFIDENCE: 68%
```

Add overlay text: "Esempi illustrativi. Performance passate non garantiscono risultati futuri."

──────────────────────────────────────────────
SECTION 5 — THE EDGE
──────────────────────────────────────────────
Header: `// COMPETITIVE_EDGE`
Title: PERCHÉ FUNZIONA.

4 terminal-card grid (2x2 on desktop, stacked on mobile):

Card 1:
Icon: Activity
`[01] ANALISI 24/7`
L'AI non dorme, non si distrae, non ha emozioni. Monitora i mercati in continuazione e ti avvisa solo quando il setup ha probabilità statistica significativa.

Card 2:
Icon: Zap
`[02] VELOCITÀ DI ESECUZIONE`
Da pattern identificato a segnale pubblicato in meno di 60 secondi. Quando vedi il segnale, sei in anticipo sulla massa.

Card 3:
Icon: Lock
`[03] ZERO CONSULENZA PERSONALIZZATA`
Ti diamo l'analisi tecnica. Tu decidi. Questo ti rende un trader, non un seguace. È anche il motivo per cui operiamo nella piena legalità.

Card 4:
Icon: Terminal
`[04] BROKER REGOLAMENTATO`
Operiamo con Fortune Prime Global, broker regolamentato ASIC (Australia, Tier-1). Spread ECN da 0.0 pip. Zero commissioni di prelievo.

──────────────────────────────────────────────
SECTION 6 — LIVE STATS BAR
──────────────────────────────────────────────
Full-width band, dark green background (#001F0A), monospace font.
4 counters in a row, animate on scroll into view:

`SIGNALS_PUBLISHED: 2,847+`
`ACTIVE_USERS: 1,200+`
`MARKETS_MONITORED: 52`
`UPTIME: 99.7%`

NOTE: All numbers must be realistic and verifiable. Do NOT inflate. Better to show "Just launched" than fake metrics.

──────────────────────────────────────────────
SECTION 7 — HOW IT WORKS
──────────────────────────────────────────────
Header: `// EXECUTION_PROTOCOL`
Title: 3 STEP PER ACCEDERE AL SISTEMA.

3 horizontal steps with terminal-numbered headers:

`STEP_01` APRI CONTO FPG
Registra un conto di trading su Fortune Prime Global usando il nostro link. È gratis, regolamentato ASIC, e richiede 5 minuti. Deposito minimo $50.
CTA: `> APRI CONTO FPG →` (links to FPG IB referral URL — placeholder: https://portal.fortuneprime.com/getview?view=register&ib=[YOUR_IB_CODE])

`STEP_02` VERIFICA E DEPOSITO
Completa la verifica KYC e effettua il primo deposito. Comunicaci il tuo ID account su Telegram per attivare l'accesso alla sala segnali.

`STEP_03` ACCEDI ALLA SALA
Ricevi l'invito al canale Telegram privato. Da quel momento, ricevi tutti i segnali in tempo reale, l'analisi giornaliera di mercato, e il supporto della community.

──────────────────────────────────────────────
SECTION 8 — TESTIMONIALS
──────────────────────────────────────────────
Header: `// USER_FEEDBACK`
Title: COSA DICONO GLI OPERATORI.

3 cards, terminal-styled, anonymized:

Card 1:
`[USER_3471]` | Membro da 4 mesi
"Prima passavo ore davanti ai grafici e sbagliavo l'entry. Adesso ricevo i setup già validati e mi concentro solo su risk management."

Card 2:
`[USER_8829]` | Membro da 7 mesi
"Il valore non è il segnale singolo. È avere un sistema che ti elimina le decisioni emotive. Questo da solo cambia tutto."

Card 3:
`[USER_1205]` | Membro da 2 mesi
"Apprezzo la trasparenza. Non promettono guadagni, spiegano il metodo. Sembra controintuitivo nel marketing, ma è il motivo per cui mi fido."

NOTE: These should be authentic. If you don't have real testimonials yet, OMIT this section entirely or label "Testimonianze in arrivo — sala lanciata recentemente."

──────────────────────────────────────────────
SECTION 9 — FAQ
──────────────────────────────────────────────
Accordion-style, each question prefixed with `? ` in monospace amber.

Q: Quanto costa l'accesso alla sala segnali?
A: L'accesso alla sala è incluso per chi apre e finanzia un conto di trading su Fortune Prime Global attraverso il nostro link. Non riceviamo pagamenti diretti dai membri. La nostra remunerazione arriva dal broker sotto forma di commissione di Introducing Broker, completamente trasparente.

Q: Siete consulenti finanziari?
A: No. Non offriamo consulenza finanziaria personalizzata, non gestiamo capitale di terzi, non riceviamo deleghe operative. Pubblichiamo analisi tecnica generica come contenuto educativo. La decisione di operare e l'esecuzione degli ordini sono sempre e solo dell'utente.

Q: Cosa significa che usate l'AI?
A: Utilizziamo algoritmi di analisi statistica e pattern recognition per scansionare i mercati e identificare setup tecnici ricorrenti su più timeframe. L'AI è uno strumento di supporto: ogni segnale viene validato da trader umani prima della pubblicazione. L'AI non sostituisce il giudizio umano, lo amplifica.

Q: Quali strumenti finanziari coprite?
A: Principalmente Forex (major e minor), oro (XAU/USD), indici principali (US30, NAS100, SPX500), e selezione di crypto major. Non operiamo su azioni singole.

Q: Quali sono i rischi?
A: Il trading su CFD e Forex comporta un rischio elevato di perdita del capitale. Tra il 74% e l'89% dei conti di trader retail perde denaro. I segnali che pubblichiamo sono analisi tecniche con probabilità statistica, non garanzie di profitto. Investi solo capitale che puoi permetterti di perdere.

Q: Perché Fortune Prime Global?
A: FPG è regolamentato ASIC (Australia, Tier-1), offre spread ECN competitivi da 0.0 pip, supporta MT4/MT5, e ha condizioni adatte sia ai trader manuali che agli Expert Advisor. La regolamentazione ASIC garantisce protezione del capitale tramite segregazione dei fondi.

──────────────────────────────────────────────
SECTION 10 — FINAL CTA
──────────────────────────────────────────────
Background: dark green gradient #001F0A → #0D0D0D

Header (monospace amber): `> ready to connect?`

Title (Bebas Neue, huge):
SMETTI DI INDOVINARE.
INIZIA A OPERARE CON UN SISTEMA.

Subtitle:
Apri il tuo conto FPG, completa la verifica, e accedi alla sala segnali. 5 minuti di setup.

Lead capture form (alternative to direct FPG link, for users not ready to register):
Input 1: Email (required)
Input 2: Username Telegram (optional)
Button: `> RICHIEDI ACCESSO PRIORITARIO`
On submit: write to Supabase `leads` table, show terminal success message:
```
[OK] Request received.
[OK] Check your email within 24h.
[INFO] Welcome to the system.
```

Primary CTA above form:
`> APRI CONTO FPG ORA` (links to IB referral)

──────────────────────────────────────────────
FOOTER — LEGAL COMPLIANCE (CRITICAL)
──────────────────────────────────────────────
Background: pure black #000000
Font: monospace, small (12-13px), dim gray (#666)

Block 1 — Brand:
[BRAND_NAME]
> a trading analysis collective

Block 2 — Links:
Disclaimer | Privacy | Termini | Contatti

Block 3 — Risk Warning (must be visible, not hidden, multiple lines):
⚠ AVVERTENZA RISCHI

I CFD sono strumenti complessi e presentano un rischio elevato di perdita di denaro a causa della leva finanziaria. Il 74-89% dei conti di clienti retail perde denaro nel trading di CFD. Valuta se hai compreso il funzionamento dei CFD e se puoi permetterti di correre questo rischio elevato.

[BRAND_NAME] non è un consulente finanziario abilitato ai sensi del D.Lgs. 58/98 (TUF). I contenuti pubblicati, inclusi segnali, analisi tecniche e materiale educativo, hanno finalità esclusivamente informative ed educative e non costituiscono consulenza finanziaria personalizzata, sollecitazione al pubblico risparmio, o raccomandazione di investimento ai sensi della normativa vigente.

[BRAND_NAME] opera come Introducing Broker affiliato a Fortune Prime Global. Riceve compensi commissionali dal broker per i clienti referenziati, in conformità al modello IB dichiarato.

Le performance passate non sono indicative di risultati futuri. Investi solo capitale che puoi permetterti di perdere integralmente.

Block 4 — Copyright:
© 2026 [BRAND_NAME] — All rights reserved.

================================================================
6. INTERACTIVE / TECHNICAL DETAILS
================================================================

ANIMATIONS (Framer Motion):
- Hero typewriter: 40ms per character, blinking cursor at end
- Terminal output blocks: cascade line-by-line on scroll into view (stagger 100ms)
- Counter animations: count up from 0 over 1.5s when entering viewport
- Glitch on CTA hover: RGB channel split 2px, duration 200ms
- Section transitions: fade-in only, NO complex parallax

CURSOR:
Custom cursor on desktop: small green square 8x8px with crosshair lines. Standard cursor on mobile.

KEYBOARD INTERACTION:
On the hero, allow typing to reveal a hidden Easter egg. If user types "help" anywhere, show a terminal modal with available commands ("about", "contact", "stats"). Pure delight, not essential.

PERFORMANCE:
- All images WebP with fallback
- Lazy load below-fold
- Preload monospace font for above-the-fold terminal text
- Lighthouse score target: 90+ on mobile

================================================================
7. ROUTING + SUPPORTING PAGES
================================================================

/disclaimer — full risk and IB disclosure (expand the footer Block 3 content into full prose with clear structure: Risk Statement, IB Disclosure, No Advisory Relationship, Past Performance, Limitation of Liability)

/privacy — GDPR-compliant privacy policy template (data collected: email, telegram handle, source URL, timestamp; data controller, retention period, rights, contact email)

/terms — Terms of Service covering: nature of service (educational), no advisory relationship, IB model disclosure, user obligations, limitation of liability, governing law (Italian), dispute resolution

================================================================
8. SEO + META
================================================================

Meta title: [BRAND_NAME] — Analisi di mercato AI per trader
Meta description: Segnali di trading generati da algoritmi AI proprietari e validati da trader professionisti. Solo analisi tecnica, zero consulenza. Conto su broker regolamentato ASIC.
Open Graph image: dark terminal screenshot with brand logo
Favicon: small green square monogram or terminal cursor

================================================================
9. WHAT NOT TO BUILD
================================================================

DO NOT include:
- Promises of returns ("guadagna €X al mese")
- Performance percentages without verifiable proof
- Pricing pages with paid signal tiers (the IB model = free access in exchange for FPG account)
- "About us" with fake founder photos and Lamborghini lifestyle imagery
- Phone numbers asking for direct contact (Telegram-only for compliance distance)
- Cryptocurrency-investment-style hype copy
- Live trading account screenshots showing huge profits

================================================================
10. DELIVERABLE CHECKLIST
================================================================

When complete, the site must:
[ ] Load in under 2s on mobile 4G
[ ] Pass Lighthouse 90+ performance/accessibility/SEO
[ ] Be fully responsive across mobile, tablet, desktop
[ ] Have all disclaimers visible in footer (no dark patterns)
[ ] Connect to Supabase for lead capture (table `leads`)
[ ] Use the FPG IB referral URL on all primary CTAs (placeholder I will replace)
[ ] Have functioning /disclaimer, /privacy, /terms pages
[ ] Display correctly in Italian without typos
[ ] Have NO false performance claims anywhere
[ ] Pass the "would CONSOB find anything misleading here?" test

Build it now. Start with the design system + hero, then iterate section by section.
```

---

## ⚙ COSE DA FARE PRIMA DI INCOLLARE IL PROMPT

1. **Scegli il nome del brand** — sostituisci `[BRAND_NAME]` ovunque (Find & Replace)
2. **Ottieni il tuo link IB FPG** — sostituisci il placeholder URL al `STEP_01`
3. **Decidi sulle testimonianze** — se non hai utenti reali ancora, rimuovi la sezione (è dichiarato nel prompt)
4. **Pensa alle stats numeriche** — il prompt le mette come placeholder. Decidi numeri realistici o omette la sezione se sei al lancio
5. **Email contatto** — Lovable chiederà un'email per il Privacy Policy: usane una dedicata tipo `legal@[brand].com`

## ⚙ COSE DA FARE DOPO LA GENERAZIONE

1. **Iterazione visiva** — chiedi a Lovable di rendere più "raw" o più "polished" se serve
2. **Connessione Supabase** — Lovable la fa nativa, ma verifica che la tabella `leads` sia creata
3. **Test legale** — passa il footer e disclaimer a un commercialista o avvocato per validazione finale. Costo medio €100-200 una tantum
4. **Test su mobile vero** — non solo simulator, usa il tuo telefono per leggere ogni sezione

Quando lo lanci su Lovable, mandami screenshot del primo output così iteriamo insieme.
